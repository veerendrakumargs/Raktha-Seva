# Rakta-Seva Connect

Healthcare Android application for blood donor management and emergency blood requests.

## Technologies Used
- Android Studio
- Java
- XML
- SQLite
